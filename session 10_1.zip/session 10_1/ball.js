class Ball {
	constructor(x, y, dx, dy, radius, img) {
		this.x = x;
		this.y = y;
		this.dx = dx;
		this.dy = dy;
		this.radius = radius;
		this.img = img;
	}
	
	draw() {
		ctx.beginPath();
		
		ctx.drawImage(this.img, this.x-this.radius, this.y-this.radius, this.radius*2, this.radius*2);
		
		ctx.closePath();
		
		this.update();
	}
	
	update() {
		// Check if ball reached the left or the right border
		if (this.x + this.dx < this.radius)
			this.dx = -this.dx;
		
		if (this.x + this.dx > canvas.width - this.radius)
			this.dx = -this.dx;
		
		// Check if ball reached the top or the bottom border
		if (this.y + this.dy < this.radius)
			this.dy = -this.dy;
			
		this.x = this.x + this.dx;
		this.y = this.y + this.dy;
	}
}