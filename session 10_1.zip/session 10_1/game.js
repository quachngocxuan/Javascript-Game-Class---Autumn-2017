function drawGame() {
	// Clear screen
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	
	// Draw balls
	for (var ball of balls)
		ball.draw();
	
	paddle.draw();
	panel.draw();
	
	// Draw bricks
	for (var brick of bricks)
		brick.draw();
	
	checkCollision();
	
	checkGameOver();
}

function resetGame() {
	balls = [
		new Ball(100, 10, 1, 1, 10, ballImg),
		new Ball(150, 10, -1, 1, 10, ballImg),
	];

	paddle.x = 0;
}

function checkGameOver() {
	var gameover = true;	// all balls go out

	for (var ball of balls) {
		if (ball.y < canvas.height + ball.radius) {
			gameover = false;
			break;
		}
	}
	
	if (gameover == true) {
		clearInterval(intervalID);
		waitToStart("GAME OVER! spacebar to start again");
		resetGame();
	}
}

function checkCollision() {
	for(var ball of balls) { 
		// check the ball collides the paddle
		if (paddle.x <= ball.x && ball.x <= paddle.x + paddle.width &&  ball.y + ball.radius == paddle.y) {
			ball.dy = -ball.dy;
			panel.point++;
			
			// Play sound
			playSound("collision.wav");
		}
		
		// check the ball collides bricks
		var len_before = bricks.length;
		// filter collided bricks
		bricks = bricks.filter(function(brick) {
			return !(brick.x < ball.x && 
				ball.x < brick.x + brick.width &&
				brick.y < ball.y &&
				ball.y < brick.y + brick.height);
		});
		if (len_before != bricks.length)
			ball.dy = -ball.dy;
			
		// Out of bricks -> next level
		if (bricks.length == 0) {
			if ((currentLevel+1) < levels.length) {
				currentLevel++;
				loadNextLevel();
			} else {
				clearInterval(intervalID);
				
				waitToStart("GOOD JOB, YOU WIN! Press spacebar to re-play game.");
				
				resetGame();
			}
		}
	}
}

function playSound(file) {
	var sound = new Audio(file);
	sound.volume = 0.1;
	sound.load();
	sound.play();
}

function waitToStart(message) {
	ctx.beginPath();
	ctx.font = "35px Courier News";
	ctx.fillStyle = "white";
	ctx.fillText(message, 20, 150);
	ctx.closePath();
	
	// wait spacebar pressed
	document.addEventListener("keydown", spacebarPressed);
}

function spacebarPressed(event) {
	if (event.keyCode == 32) { // spacebar
		startGame();
		document.removeEventListener("keydown", spacebarPressed);
	}
}

function startGame() {
	intervalID = setInterval(drawGame, 10); // call drawBall every 10 milliseconds

	// Capture arrow keys
	document.addEventListener("keydown", function(event) {
		paddle.update(event.keyCode);
	});
}

function initGame() {
	waitToStart("PRESS Spacebar to START...");
	
	loadNextLevel();
}

function loadNextLevel() {
	bricks = [];
	var pattern = levels[currentLevel];	// first level: [1,1,1,1]
	var x = 20;
	var y = 50;
	var width = 50;
	var height = 20;
	var padding = 10;
	var count = 0;
	for (var b of pattern) {
		count = count + 1; 	// count++;
		
		if (b == 1) {
			var newBrick = new Brick(x, y, width, height, brickImg);
			bricks.push(newBrick);
		}
		
		// If end of row
		if (count%5 == 0) {
			x = 20;
			y = y + height + padding;
		} else {
			x = x + width + padding;
		}
	}
}

// Get the canvas
var canvas = document.getElementById("myCanvas");
var ctx = canvas.getContext("2d");
var intervalID;

var ballImg = new Image();
ballImg.src = "ball.png";
// this array holds balls
var balls = [
	new Ball(100, 10, 1, 1, 10, ballImg),
	new Ball(150, 10, -1, 1, 10, ballImg),
];

// Create new Panel object
var panel = new Panel(0, 0);

var paddle = new Paddle(0, canvas.height - 10, 100, 10);

var brickImg = new Image();
brickImg.src = "brick.png";

var bricks = [
	new Brick(20, 50, 50, 20, brickImg),
	new Brick(80, 50, 50, 20, brickImg),
	new Brick(140, 50, 50, 20, brickImg)
];

var levels = [ [1,1,1,1,1],
			   [1,1,1,1,1,
			    1,0,0,0,1],
			   [0,0,1,0,0,
			    0,1,1,1,0,
			    1,1,1,1,1]
			 ];
var currentLevel = 0;
			  
initGame();