class Panel {
	constructor(point, die) {
		// Define properties
		this.point = point;
		this.die = die;
	}
	
	// Define methods
	draw() {
		ctx.beginPath();
		ctx.font = "20px Arial";
		ctx.fillText("Points: " + this.point, 10, 20);
		ctx.fillText("Die: " + this.die, 400, 20);
		ctx.closePath();
	}
}