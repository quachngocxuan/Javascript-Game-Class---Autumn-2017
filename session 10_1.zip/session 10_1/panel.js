class Panel {
	constructor(point) {
		// Define properties
		this.point = point;
	}
	
	// Define methods
	draw() {
		ctx.beginPath();
		ctx.font = "20px Arial";
		ctx.fillStyle = "white";
		ctx.fillText("Points: " + this.point, 10, 20);
		ctx.closePath();
	}
}