class Paddle {
	constructor(x, y, width, height) {
		// Define properties
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	draw() {
		ctx.beginPath();
		ctx.rect(this.x, canvas.height - this.height, this.width, this.height);
		ctx.fillStyle = "blue";
		ctx.fill();
		ctx.closePath();
	}

	// update postition of the paddle
	// - keyCode: key was pressed (arrow left: 37, arrow right: 39)
	update(keyCode) {
		if (keyCode == 37)	// arrow LEFT
			if (this.x > 0)
				this.x = this.x - 10;
		
		if (keyCode == 39)	// arrow RIGHT
			if (this.x < canvas.width - this.width)
				this.x = this.x + 10;
	}
}