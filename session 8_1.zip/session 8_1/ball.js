function drawBall() {
	for (var ball of balls) {
		ctx.beginPath();
		
		var ballImg = new Image();
		ballImg.src = "ball.png";
		ctx.drawImage(ballImg, ball.x-10, ball.y-10, 20, 20);
		
		ctx.closePath();
		
		// Check if ball reached the left or the right border
		if (ball.x + ball.dx < ball.radius)
			ball.dx = -ball.dx;
		
		if (ball.x + ball.dx > canvas.width - ball.radius)
			ball.dx = -ball.dx;
		
		// Check if ball reached the top or the bottom border
		if (ball.y + ball.dy < ball.radius)
			ball.dy = -ball.dy;
			
		ball.x = ball.x + ball.dx;
		ball.y = ball.y + ball.dy;
	}	
}

function getRandomBall() {
	var minus = 1;
	var rndNum = Math.random();
	if (rndNum < 0.5)
		minus = -1;
		
	var ball = {
		x: Math.floor((Math.random() * (canvas.width-2*10)) + 1) + 10, 
		y: 10, 
		dx: minus, 
		dy: 1, 
		radius: 10
	}
	
	return ball;
}