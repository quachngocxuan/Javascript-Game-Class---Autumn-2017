function drawPanel() {
	ctx.beginPath();
	ctx.font = "20px Arial";
	ctx.fillText("Points: " + panel.point, 10, 20);
	ctx.fillText("Die: " + panel.die, 400, 20);
	ctx.closePath();
}