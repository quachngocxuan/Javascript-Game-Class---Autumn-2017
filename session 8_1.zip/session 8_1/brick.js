function drawBricks() {
	var brickImg = new Image();
	brickImg.src = "brick.png";
	
	for (var brick of bricks) {
		ctx.beginPath();
		ctx.drawImage(brickImg, brick.x, brick.y, brick.width, brick.height);
		ctx.fillStyle = "white";
		ctx.fill();
		ctx.closePath();
	}
}