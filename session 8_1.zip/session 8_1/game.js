function drawGame() {
	// Clear screen
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	
	drawBall();
	drawPaddle();
	drawPanel();
	drawBricks();
	
	checkCollision();
	
	checkGameOver();
}

function resetGame() {
	balls = [
	  getRandomBall(),
	  getRandomBall(),
	  getRandomBall()
	];

	paddle.x = 0;
}

function checkGameOver() {
	var gameover = true;	// all balls go out

	for (var ball of balls) {
		if (ball.y < canvas.height + ball.radius) {
			gameover = false;
			break;
		}
	}
	
	if (gameover == true) {
		clearInterval(intervalID);
		waitToStart("GAME OVER! spacebar to start again");
		resetGame();
	}
}

function checkCollision() {
	for(var ball of balls) { 
		// check the ball collides the paddle
		if (paddle.x <= ball.x && ball.x <= paddle.x + paddle.width &&  ball.y + ball.radius == paddle.y) {
			ball.dy = -ball.dy;
			panel.point++;
			
			// Play sound
			playSound("collision.wav");
		}
		
		// check the ball collides bricks
		var len_before = bricks.length;
		// filter collided bricks
		bricks = bricks.filter(function(brick) {
			return !(brick.x < ball.x && 
				ball.x < brick.x + brick.width &&
				brick.y < ball.y &&
				ball.y < brick.y + brick.height);
		});
		if (len_before != bricks.length)
			ball.dy = -ball.dy;
	}
}

function playSound(file) {
	var sound = new Audio(file);
	sound.volume = 0.1;
	sound.load();
	sound.play();
}

function waitToStart(message) {
	ctx.beginPath();
	ctx.font = "35px Courier News";
	ctx.fillStyle = "white";
	ctx.fillText(message, 20, 150);
	ctx.closePath();
	
	// wait spacebar pressed
	document.addEventListener("keydown", spacebarPressed);
}

function spacebarPressed(event) {
	if (event.keyCode == 32) { // spacebar
		startGame();
		document.removeEventListener("keydown", spacebarPressed);
	}
}

function startGame() {
	intervalID = setInterval(drawGame, 10); // call drawBall every 10 milliseconds

	// Capture arrow keys
	document.addEventListener("keydown", function(event) {
		updatePaddle(event.keyCode);
	});
}

function initGame() {
	// Get the canvas
	canvas = document.getElementById("myCanvas");
	ctx = canvas.getContext("2d");

	waitToStart("PRESS Spacebar to START...");
}

var canvas;
var ctx;
var intervalID;

initGame();

// this array holds balls
var balls = [
	getRandomBall(),
	getRandomBall(),
	getRandomBall()
];

var panel = {
	point: 0,
	die: 0
};

var paddle = {
	x: 0, 
	y: canvas.height - 10, 
	width: 100, 
	height: 10
};

var bricks = [
	{
		x: 20,
		y: 50,
		width: 50,
		height: 20
	},
	{
		x: 80,
		y: 50,
		width: 50,
		height: 20
	},
	{
		x: 140,
		y: 50,
		width: 50,
		height: 20
	}
];