class Ball {
	constructor(x, y, dx, dy, radius, img) {
		this.x = x;
		this.y = y;
		this.dx = dx;
		this.dy = dy;
		this.radius = radius;
		this.img = img;
	}
	
	draw() {
		ctx.beginPath();
		
		ctx.drawImage(this.img, this.x-this.radius, this.y-this.radius, this.radius*2, this.radius*2);
		
		ctx.closePath();
		
		this.update();
	}
	
	update() {
		// Check if ball reached the left or the right border
		if (this.x + this.dx < this.radius)
			this.dx = -this.dx;
		
		if (this.x + this.dx > canvas.width - this.radius)
			this.dx = -this.dx;
		
		// Check if ball reached the top or the bottom border
		if (this.y + this.dy < this.radius)
			this.dy = -this.dy;
			
		this.x = this.x + this.dx;
		this.y = this.y + this.dy;
	}

	/*
	getRandomBall() {
		var minus = 1;
		var rndNum = Math.random();
		if (rndNum < 0.5)
			minus = -1;
			
		var ball = {
			x: Math.floor((Math.random() * (canvas.width-2*10)) + 1) + 10, 
			y: 10, 
			dx: minus, 
			dy: 1, 
			radius: 10
		}
		
		return ball;
	}
	*/
}