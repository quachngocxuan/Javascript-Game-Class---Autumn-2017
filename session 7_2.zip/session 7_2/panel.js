function drawPanel() {
	ctx.beginPath();
	ctx.font = "20px Arial";
	ctx.fillText("Points: " + panel.point, 10, 50);
	ctx.fillText("Die: " + panel.die, 400, 50);
	ctx.closePath();
}