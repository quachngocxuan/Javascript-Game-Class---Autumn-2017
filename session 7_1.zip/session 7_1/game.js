function drawGame() {
	// Clear screen
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	
	drawBall();
	drawPaddle();
	drawPanel();
	
	checkCollision();
	
	checkGameOver();
}

function resetGame() {
	balls = [
	  getRandomBall(),
	  getRandomBall(),
	  getRandomBall()
	];

	paddle.x = 0;
}

function checkGameOver() {
	var gameover = true;	// all balls go out

	for (var ball of balls) {
		if (ball.y < canvas.height + ball.radius) {
			gameover = false;
			break;
		}
	}
	
	if (gameover == true) {
		alert("Game over");
		resetGame();
	}
}

function checkCollision() {
	for(var ball of balls) { 
		// check the ball collides the paddle
		if (paddle.x <= ball.x && ball.x <= paddle.x + paddle.width &&  ball.y + ball.radius == paddle.y) {
			ball.dy = -ball.dy;
			panel.point++;
		}
	}
}

function initGame() {
	// Get the canvas
	canvas = document.getElementById("myCanvas");
	ctx = canvas.getContext("2d");

	setInterval(drawGame, 10); // call drawBall every 10 milliseconds

	// Capture arrow keys
	document.addEventListener("keydown", function(event) {
		updatePaddle(event.keyCode);
	});
}

var canvas;
var ctx;

initGame();

// this array holds balls
var balls = [
	getRandomBall(),
	getRandomBall(),
	getRandomBall()
];

var panel = {
	point: 0,
	die: 0
};

var paddle = {
	x: 0, 
	y: canvas.height - 10, 
	width: 100, 
	height: 10
};