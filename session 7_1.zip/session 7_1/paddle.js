function drawPaddle() {
	ctx.beginPath();
	ctx.rect(paddle.x, canvas.height - paddle.height, paddle.width, paddle.height);
	ctx.fillStyle = "blue";
	ctx.fill();
	ctx.closePath();
}

// update postition of the paddle
// - keyCode: key was pressed (arrow left: 37, arrow right: 39)
function updatePaddle(keyCode) {
	if (keyCode == 37)	// arrow LEFT
		if (paddle.x > 0)
			paddle.x = paddle.x - 10;
	
	if (keyCode == 39)	// arrow RIGHT
		if (paddle.x < canvas.width - paddle.width)
			paddle.x = paddle.x + 10;
}